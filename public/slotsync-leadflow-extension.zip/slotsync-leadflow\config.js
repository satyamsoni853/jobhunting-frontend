// SlotSync LeadFlow settings. Edit the two values below, save, then reload the extension in chrome://extensions.
// url: your ColdMailer server (the backend that sends the mails).
// key: the Access Key set as AUTO_API_KEY on that server. Leave it empty to only collect emails without sending them.
self.COLDMAILER_CONFIG = {
  url: 'https://jobhunting-backend.onrender.com',
  key: '',
};
