// SlotSync LeadFlow background worker
chrome.runtime.onInstalled.addListener(() => {
  console.log("SlotSync LeadFlow installed.");
  // Clear storage to start fresh on extension install/reload
  chrome.storage.local.clear(() => {
    chrome.storage.local.set({ emails: [], active: false, autoExpand: true });
  });
});

// Content script cannot call the ColdMailer server directly from linkedin.com, so it goes through here
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action !== "AUTO_ENQUEUE") return;
  fetch(`${request.serverUrl}/api/auto-enqueue`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-Key": request.apiKey },
    body: JSON.stringify({ emails: request.emails, postUrl: request.postUrl }),
  })
    .then(async (r) => {
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || `API Error: ${r.status}`);
      sendResponse({ success: true, data });
    })
    .catch((error) => sendResponse({ success: false, error: error.message }));
  return true; // respond asynchronously
});

chrome.runtime.onStartup.addListener(() => {
  // Clear storage on browser startup
  chrome.storage.local.clear(() => {
    chrome.storage.local.set({ emails: [], active: false, autoExpand: true });
  });
});
