// SlotSync LeadFlow bridge. Runs only on the Job Hunter website.
// The site posts "START" / "STOP" messages; this script runs the LinkedIn searches one by one through the background
// worker and posts the progress back. The Access Key stays in the extension: the site never sees it.
(function () {
  if (window.__jhBridge) return;
  window.__jhBridge = true;

  const VERSION = 1;
  const state = { running: false, status: 'idle', index: 0, total: 0, query: '', emails: 0, posts: 0, message: '', minutesLeft: null };
  let stopRequested = false;

  const post = (type, extra = {}) => window.postMessage({ src: 'jh-agent', type, version: VERSION, state: { ...state }, ...extra }, window.location.origin);
  const ask = (message) => new Promise((resolve) => chrome.runtime.sendMessage(message, (res) => resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : res || { ok: false, error: 'No answer from the extension.' })));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);

  // a pause the Stop button can cut short
  async function pause(ms) {
    for (let waited = 0; waited < ms && !stopRequested; waited += 1000) await sleep(1000);
  }

  function shuffle(list) {
    const a = [...list];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  const finish = (status, message) => {
    Object.assign(state, { running: false, status, message });
    post('STATE');
  };

  async function start(options) {
    if (state.running) return;
    const maxQueries = Math.max(1, Math.min(Number(options.maxQueries) || 8, 20));
    const steps = Math.max(4, Math.min(Number(options.steps) || 14, 30));
    stopRequested = false;
    Object.assign(state, { running: true, status: 'starting', index: 0, total: 0, query: '', emails: 0, posts: 0, message: '' });
    post('STATE');

    // the searches come from the server (the categories chosen on the site), never from the page
    const got = await ask({ action: 'AGENT_GET_QUERIES' });
    if (!got.ok) return finish('error', got.error);
    if (!got.queries.length) return finish('error', 'No job category is selected. Choose at least one above.');

    const queries = shuffle(got.queries).slice(0, maxQueries);
    state.total = queries.length;
    state.status = 'running';

    for (let i = 0; i < queries.length && !stopRequested; i++) {
      Object.assign(state, { index: i + 1, query: queries[i], message: '' });
      post('STATE');

      const r = await ask({ action: 'AGENT_RUN_QUERY', query: queries[i], steps });
      if (r.minutesLeft !== undefined) state.minutesLeft = r.minutesLeft;
      if (r.blocked) {
        await ask({ action: 'AGENT_CLOSE' });
        return finish('blocked', 'LinkedIn showed a login or security check. Stopped. Open LinkedIn yourself, sign in, then try again later.');
      }
      if (r.limit) {
        await ask({ action: 'AGENT_CLOSE' });
        return finish('limit', r.error);
      }
      if (r.ok) {
        state.emails += r.emails || 0;
        state.posts += r.posts || 0;
      } else {
        state.message = r.error || 'This search failed and was skipped.';
      }
      post('STATE');

      // a human does not search again at once
      if (i < queries.length - 1) await pause(rand(25000, 60000));
    }

    await ask({ action: 'AGENT_CLOSE' });
    finish(stopRequested ? 'stopped' : 'done', stopRequested ? 'Stopped.' : 'Finished.');
  }

  window.addEventListener('message', (event) => {
    const data = event.data;
    if (event.source !== window || !data || data.src !== 'jh-site') return;
    if (data.type === 'PING') post('READY');
    else if (data.type === 'START') start(data);
    else if (data.type === 'STOP') {
      stopRequested = true;
      ask({ action: 'AGENT_STOP' }).then(() => {
        if (state.running) return;
        finish('stopped', 'Stopped.');
      });
    }
  });

  post('READY');
})();
