SlotSync LeadFlow - Chrome extension

Install
1. Unzip this folder somewhere permanent (Chrome reads it from there, do not delete it).
2. Open chrome://extensions and turn on Developer mode (top right).
3. Click "Load unpacked" and select the unzipped slotsync-leadflow folder.
4. Open config.js in a text editor, set your server url and your Access Key, save,
   then press the reload icon on the extension in chrome://extensions.

Use
- Open LinkedIn, press the round button, turn on monitoring and scroll.
- Emails found in posts are listed in the panel. With an Access Key set, each new email is
  sent to your ColdMailer server together with the post text, so the server can tailor the
  resume and note to that post and mail it in the background.
- Without a key the extension only collects emails (use Export CSV).

Notes
- Your Access Key stays on your computer in config.js. Do not share this folder after adding it.
- LinkedIn's terms restrict automated collection. Scroll yourself at a normal pace and use it at your own risk.
