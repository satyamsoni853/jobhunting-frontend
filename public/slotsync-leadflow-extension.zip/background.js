// SlotSync LeadFlow background worker
importScripts("config.js"); // gives self.COLDMAILER_CONFIG (server url and Access Key)
chrome.runtime.onInstalled.addListener(() => {
  console.log("SlotSync LeadFlow installed.");
  // Clear storage to start fresh on extension install/reload
  chrome.storage.local.clear(() => {
    chrome.storage.local.set({ emails: [], active: false, autoExpand: true });
  });
});

// Content script cannot call the ColdMailer server directly from linkedin.com, so it goes through here
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action !== "AUTO_ENQUEUE") return;
  fetch(`${request.serverUrl}/api/auto-enqueue`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-Key": request.apiKey },
    body: JSON.stringify({ emails: request.emails, postUrl: request.postUrl, postText: request.postText, author: request.author }),
  })
    .then(async (r) => {
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || `API Error: ${r.status}`);
      sendResponse({ success: true, data });
    })
    .catch((error) => sendResponse({ success: false, error: error.message }));
  return true; // respond asynchronously
});

chrome.runtime.onStartup.addListener(() => {
  // Clear storage on browser startup
  chrome.storage.local.clear(() => {
    chrome.storage.local.set({ emails: [], active: false, autoExpand: true });
  });
});

// =====================================================================
// LinkedIn agent. The website's Start button (through bridge.js) asks for one search at a time.
// Each search opens in a small separate window, because LinkedIn only loads more posts in a visible page.
// Limits, so it behaves like a person and not like a bot: at most one hour of browsing a day (kept in storage.sync,
// which a browser restart does not clear), a limited number of scroll steps per search, a pause between searches
// (bridge.js), and a full stop the moment LinkedIn shows a login or "verify you are human" page.
// =====================================================================
const AGENT_DAILY_MS = 60 * 60 * 1000;
const agentSleep = (ms) => new Promise((r) => setTimeout(r, ms));
const dayKey = () => new Date().toISOString().slice(0, 10);

async function usedTodayMs() {
  const { agentUsage } = await chrome.storage.sync.get("agentUsage");
  return agentUsage && agentUsage.day === dayKey() ? agentUsage.ms : 0;
}

async function addUsage(ms) {
  await chrome.storage.sync.set({ agentUsage: { day: dayKey(), ms: (await usedTodayMs()) + ms } });
}

async function getAgentWin() {
  const { agentWin } = await chrome.storage.session.get("agentWin");
  return agentWin || { windowId: null, tabId: null };
}

const setAgentWin = (agentWin) => chrome.storage.session.set({ agentWin });

function waitForLoad(tabId, ms = 45000) {
  return new Promise((resolve) => {
    let sawLoading = false;
    const done = () => {
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      resolve();
    };
    const listener = (id, info) => {
      if (id !== tabId) return;
      if (info.status === "loading") sawLoading = true;
      if (info.status === "complete" && sawLoading) done();
    };
    const timer = setTimeout(done, ms);
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function openSearch(url) {
  const win = await getAgentWin();
  if (win.tabId !== null) {
    try {
      await chrome.tabs.get(win.tabId);
      const loaded = waitForLoad(win.tabId);
      await chrome.tabs.update(win.tabId, { url });
      await loaded;
      return win.tabId;
    } catch {
      /* the window was closed: open a new one below */
    }
  }
  const created = await chrome.windows.create({ url, focused: false, width: 700, height: 860, type: "normal" });
  const tabId = created.tabs[0].id;
  await setAgentWin({ windowId: created.id, tabId });
  await waitForLoad(tabId);
  return tabId;
}

async function closeAgentWindow() {
  const win = await getAgentWin();
  if (win.windowId !== null) {
    try {
      await chrome.windows.remove(win.windowId);
    } catch {
      /* already closed */
    }
  }
  await setAgentWin({ windowId: null, tabId: null });
}

async function runInTab(tabId, steps) {
  // the page script needs a moment after the load before it can answer
  for (let i = 0; i < 10; i++) {
    try {
      return await chrome.tabs.sendMessage(tabId, { action: "AGENT_RUN", steps });
    } catch {
      await agentSleep(1500);
    }
  }
  return { ok: false, error: "The LinkedIn page did not answer. Is LinkedIn logged in, and is the extension reloaded?" };
}

async function handleAgent(req) {
  const cfg = self.COLDMAILER_CONFIG || {};
  switch (req.action) {
    case "AGENT_GET_QUERIES": {
      if (!cfg.url || !cfg.key) return { ok: false, error: "Set the server url and Access Key in config.js, then reload the extension." };
      const r = await fetch(`${cfg.url}/api/search-queries`, { headers: { "X-API-Key": cfg.key } });
      if (r.status === 401) return { ok: false, error: "The Access Key in config.js is wrong." };
      if (!r.ok) return { ok: false, error: `Server error ${r.status}` };
      const d = await r.json();
      return { ok: true, queries: d.queries || [], selected: d.selected || [] };
    }
    case "AGENT_RUN_QUERY": {
      const used = await usedTodayMs();
      if (used >= AGENT_DAILY_MS) return { ok: false, limit: true, error: "Today's LinkedIn time limit (1 hour) is used up. It resets tomorrow." };
      const started = Date.now();
      const url = `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(req.query)}&origin=FACETED_SEARCH&sortBy=%22date_posted%22`;
      let result;
      try {
        const tabId = await openSearch(url);
        result = await Promise.race([runInTab(tabId, req.steps), agentSleep(4 * 60 * 1000).then(() => ({ ok: false, error: "This search took too long and was skipped." }))]);
      } finally {
        await addUsage(Date.now() - started);
      }
      return { ...result, minutesLeft: Math.max(0, Math.round((AGENT_DAILY_MS - (await usedTodayMs())) / 60000)) };
    }
    case "AGENT_STOP": {
      const win = await getAgentWin();
      if (win.tabId !== null) chrome.tabs.sendMessage(win.tabId, { action: "AGENT_ABORT" }).catch(() => {});
      await closeAgentWindow();
      return { ok: true };
    }
    case "AGENT_CLOSE":
      await closeAgentWindow();
      return { ok: true };
    default:
      return { ok: false, error: "Unknown request" };
  }
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (!req || typeof req.action !== "string" || !req.action.startsWith("AGENT_")) return undefined;
  handleAgent(req)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, error: e.message }));
  return true; // respond asynchronously
});

// the user closed the agent window by hand
chrome.windows.onRemoved.addListener(async (windowId) => {
  const win = await getAgentWin();
  if (win.windowId === windowId) await setAgentWin({ windowId: null, tabId: null });
});
