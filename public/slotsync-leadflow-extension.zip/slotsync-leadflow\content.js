// SlotSync LeadFlow - Content Script

(function () {
  // Prevent duplicate insertion
  if (shadowRootExists()) {
    return;
  }

  function shadowRootExists() {
    return !!document.getElementById('nova-email-extractor-container');
  }

  // --- STATE ---
  let active = false; // Always starts paused on reload
  let autoExpand = false;
  let emails = [];
  let sessionScannedCount = 0;
  const processedPosts = new Map(); // Tracks processed post URNs -> textLength during current page load
  let globalScanInterval = null;
  let tempPostIdCounter = 0;
  let justAddedNewEmail = false;

  // --- COLDMAILER AUTO-SEND ---
  // Every newly found email is pushed to the ColdMailer server, which mails it in the background.
  // The server URL and Access Key live in config.js so each user sets their own.
  const COLDMAILER_URL = (self.COLDMAILER_CONFIG && self.COLDMAILER_CONFIG.url) || '';
  const COLDMAILER_KEY = (self.COLDMAILER_CONFIG && self.COLDMAILER_CONFIG.key) || '';
  const AUTO_SEND = Boolean(COLDMAILER_URL && COLDMAILER_KEY); // no key: only collect, never send
  const syncedEmails = new Set(); // already pushed during this page load

  // Broad set of selectors to catch posts in feed, search results, articles, etc.
  const postSelector = [
    '.feed-shared-update-v2',
    '.occludable-update',
    '.reusable-search__result-container',
    '.entity-result',
    'article',
    '[data-urn]',
    '[data-activity-urn]',
    '[data-view-name="search-results-post"]',
    '.search-results__list-item',
    '.search-marvel-srp__card-manifestation',
    '[class*="feed-shared-update"]',
    '[class*="entity-result"]',
    '.update-components-actor__container',
    '.feed-shared-update'
  ].join(', ');

  // --- HTML UTILS ---
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // --- UI CONSTRUCTION ---
  const container = document.createElement('div');
  container.id = 'nova-email-extractor-container';
  document.body.appendChild(container);

  const shadow = container.attachShadow({ mode: 'open' });

  // Styles
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    :host {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color-scheme: dark;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    /* Floating Action Button (FAB) */
    .fab {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: linear-gradient(135deg, #f97316 0%, #f43f5e 100%);
      box-shadow: 0 8px 32px rgba(249, 115, 22, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.2);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 2147483647;
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .fab:hover {
      transform: scale(1.1) translateY(-4px);
      box-shadow: 0 12px 40px rgba(249, 115, 22, 0.6), inset 0 2px 4px rgba(255, 255, 255, 0.3);
    }
    
    .fab svg {
      width: 28px;
      height: 28px;
      fill: #ffffff;
      transition: transform 0.3s ease;
    }
    
    .fab:hover svg {
      transform: rotate(12deg);
    }
    
    .fab-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ef4444;
      color: white;
      font-size: 11px;
      font-weight: 700;
      min-width: 22px;
      height: 22px;
      border-radius: 11px;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 6px;
      border: 2px solid #0a0c16;
      box-shadow: 0 4px 10px rgba(239, 68, 68, 0.4);
      transition: transform 0.3s ease;
    }
    
    /* Sidebar Drawer */
    .sidebar {
      position: fixed;
      top: 0;
      right: -400px;
      width: 380px;
      height: 100vh;
      background: rgba(10, 12, 22, 0.88);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border-left: 1px solid rgba(255, 255, 255, 0.08);
      box-shadow: -10px 0 40px rgba(0, 0, 0, 0.5);
      z-index: 2147483647;
      transition: right 0.4s cubic-bezier(0.16, 1, 0.3, 1);
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    
    .sidebar.open {
      right: 0;
    }
    
    /* Header styling */
    .header {
      padding: 24px 20px;
      background: rgba(255, 255, 255, 0.02);
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    
    .header-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .title-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .logo-icon {
      width: 32px;
      height: 32px;
      border-radius: 8px;
      background: linear-gradient(135deg, #f97316 0%, #f43f5e 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(249, 115, 22, 0.3);
    }
    
    .logo-icon svg {
      width: 18px;
      height: 18px;
      fill: white;
    }
    
    .title {
      font-size: 18px;
      font-weight: 700;
      background: linear-gradient(120deg, #ffffff 30%, #ffedd5 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: -0.5px;
    }
    
    .close-btn {
      background: none;
      border: none;
      cursor: pointer;
      color: #9ca3af;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      transition: all 0.2s ease;
    }
    
    .close-btn:hover {
      background: rgba(255, 255, 255, 0.08);
      color: #ffffff;
      transform: rotate(90deg);
    }
    
    .close-btn svg {
      width: 18px;
      height: 18px;
      stroke: currentColor;
      stroke-width: 2.5;
    }
    
    /* Controls section */
    .control-group {
      display: flex;
      flex-direction: column;
      gap: 12px;
      background: rgba(255, 255, 255, 0.03);
      padding: 14px;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.04);
    }
    
    .control-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .control-label {
      font-size: 13px;
      font-weight: 500;
      color: #e5e7eb;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    
    .control-sub {
      font-size: 11px;
      color: #9ca3af;
      font-weight: 400;
    }
    
    /* Toggle Switch */
    .switch {
      position: relative;
      display: inline-block;
      width: 44px;
      height: 24px;
    }
    
    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #374151;
      transition: .3s;
      border-radius: 24px;
      border: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 18px;
      width: 18px;
      left: 2px;
      bottom: 2px;
      background-color: #ffffff;
      transition: .3s;
      border-radius: 50%;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    input:checked + .slider {
      background-color: #f97316;
      background: linear-gradient(135deg, #f97316 0%, #f43f5e 100%);
      box-shadow: 0 0 10px rgba(249, 115, 22, 0.4);
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Status Info Box */
    .stats-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-top: 4px;
    }
    
    .stat-card {
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid rgba(255, 255, 255, 0.04);
      border-radius: 10px;
      padding: 10px;
      text-align: center;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    
    .stat-val {
      font-size: 18px;
      font-weight: 700;
      font-variant-numeric: tabular-nums;
    }
    
    .stat-val.scans {
      color: #38bdf8;
      text-shadow: 0 0 8px rgba(56, 189, 248, 0.2);
    }
    
    .stat-val.emails {
      color: #f97316;
      text-shadow: 0 0 8px rgba(249, 115, 22, 0.2);
    }
    
    .stat-lbl {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
    }
    
    /* List Section */
    .content-list {
      flex: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    
    .content-list::-webkit-scrollbar {
      width: 6px;
    }
    
    .content-list::-webkit-scrollbar-track {
      background: transparent;
    }
    
    .content-list::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.12);
      border-radius: 3px;
    }
    
    .content-list::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.25);
    }
    
    /* Empty state */
    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 40px 20px;
      text-align: center;
      color: #6b7280;
      margin: auto 0;
    }
    
    .empty-state svg {
      width: 44px;
      height: 44px;
      fill: none;
      stroke: #4b5563;
      stroke-width: 1.5;
    }
    
    .empty-title {
      font-size: 14px;
      font-weight: 600;
      color: #9ca3af;
    }
    
    .empty-desc {
      font-size: 12px;
      line-height: 1.5;
      max-width: 220px;
      color: #6b7280;
    }
    
    /* Email Card */
    .card {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 12px;
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      transition: all 0.2s ease;
      position: relative;
      overflow: hidden;
    }
    
    .card:hover {
      background: rgba(255, 255, 255, 0.05);
      border-color: rgba(249, 115, 22, 0.25);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 8px;
    }
    
    .email-display {
      font-size: 13px;
      font-weight: 600;
      color: #ffffff;
      word-break: break-all;
      user-select: all;
    }
    
    .copy-btn {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.08);
      color: #e5e7eb;
      cursor: pointer;
      padding: 6px;
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
      flex-shrink: 0;
    }
    
    .copy-btn:hover {
      background: #f97316;
      color: #ffffff;
      border-color: transparent;
    }
    
    .copy-btn svg {
      width: 14px;
      height: 14px;
      fill: currentColor;
    }
    
    .card-meta {
      display: flex;
      flex-direction: column;
      gap: 4px;
      font-size: 12px;
    }
    
    .meta-author {
      font-weight: 500;
      color: #f97316;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    
    .meta-author:hover {
      text-decoration: underline;
    }
    
    .meta-author svg {
      width: 12px;
      height: 12px;
      stroke: currentColor;
      stroke-width: 2;
      fill: none;
    }
    
    .meta-snippet {
      color: #9ca3af;
      font-size: 11px;
      line-height: 1.4;
      font-style: italic;
      background: rgba(0, 0, 0, 0.15);
      padding: 6px 8px;
      border-radius: 6px;
      margin-top: 2px;
      max-height: 60px;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
    }
    
    .card-bottom {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 2px;
    }
    
    .post-link {
      font-size: 11px;
      color: #38bdf8;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 4px;
      font-weight: 500;
    }
    
    .post-link:hover {
      text-decoration: underline;
    }
    
    .post-link svg {
      width: 10px;
      height: 10px;
      fill: currentColor;
    }
    
    .post-time {
      font-size: 10px;
      color: #6b7280;
    }
    
    /* Footer Section */
    .footer {
      padding: 20px;
      background: rgba(255, 255, 255, 0.02);
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    
    .footer-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }
    
    .action-btn {
      border: none;
      cursor: pointer;
      font-weight: 600;
      font-size: 13px;
      padding: 10px 16px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s ease;
    }
    
    .action-btn.primary {
      background: linear-gradient(135deg, #f97316 0%, #f43f5e 100%);
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(249, 115, 22, 0.2);
    }
    
    .action-btn.primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 16px rgba(249, 115, 22, 0.35);
    }
    
    .action-btn.secondary {
      background: rgba(255, 255, 255, 0.06);
      color: #f3f4f6;
      border: 1px solid rgba(255, 255, 255, 0.08);
    }
    
    .action-btn.secondary:hover {
      background: rgba(255, 255, 255, 0.1);
      color: #ffffff;
    }
    
    .action-btn.danger {
      background: rgba(239, 68, 68, 0.08);
      color: #f87171;
      border: 1px solid rgba(239, 68, 68, 0.15);
      justify-content: center;
    }
    
    .action-btn.danger:hover {
      background: #ef4444;
      color: #ffffff;
      border-color: transparent;
    }
    
    .action-btn svg {
      width: 16px;
      height: 16px;
      fill: currentColor;
    }
    
    /* Toast Notification */
    .toast {
      position: absolute;
      bottom: 85px;
      left: 50%;
      transform: translateX(-50%) translateY(15px);
      background: rgba(16, 185, 129, 0.95);
      color: #ffffff;
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
      opacity: 0;
      pointer-events: none;
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      z-index: 100;
    }
    
    .toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
    
    /* Diagnostics Console */
    .debug-console {
      margin-top: 12px;
      padding: 10px 12px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px dashed rgba(249, 115, 22, 0.25);
      border-radius: 8px;
      font-family: monospace;
      font-size: 10px;
      color: #cbd5e1;
      max-height: 120px;
      overflow-y: auto;
    }
    .debug-console-title {
      font-weight: 700;
      font-size: 9px;
      text-transform: uppercase;
      margin-bottom: 6px;
      display: flex;
      justify-content: space-between;
      color: #f97316;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      padding-bottom: 4px;
    }
    .title-wrapper {
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .subtitle {
      font-size: 9px;
      color: #f97316;
      font-weight: 600;
      margin-top: 1px;
      letter-spacing: 0.3px;
      text-transform: uppercase;
    }
    .developer-signature {
      margin-top: 12px;
      font-size: 11px;
      text-align: center;
      color: #9ca3af;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      padding-top: 10px;
      display: flex;
      flex-direction: column;
      gap: 3px;
      line-height: 1.3;
    }
    .developer-signature strong {
      color: #ffffff;
      font-weight: 600;
    }
    .developer-signature a {
      color: #f97316;
      text-decoration: none;
      font-weight: 600;
      transition: all 0.2s ease;
    }
    .developer-signature a:hover {
      color: #ffedd5;
      text-shadow: 0 0 8px rgba(249, 115, 22, 0.4);
    }

    @keyframes fabPulseBounce {
      0% {
        transform: scale(1);
        box-shadow: 0 8px 32px rgba(249, 115, 22, 0.4);
      }
      20% {
        transform: scale(1.15) translateY(-6px);
        box-shadow: 0 20px 48px rgba(249, 115, 22, 0.7), 0 0 0 10px rgba(249, 115, 22, 0);
      }
      40% {
        transform: scale(0.95) translateY(2px);
      }
      60% {
        transform: scale(1.05) translateY(-2px);
      }
      80% {
        transform: scale(0.98) translateY(0);
      }
      100% {
        transform: scale(1);
        box-shadow: 0 8px 32px rgba(249, 115, 22, 0.4);
      }
    }

    .fab.animate-pulse-bounce {
      animation: fabPulseBounce 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    @keyframes badgePop {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.5);
        background-color: #ffffff;
        color: #f97316;
        box-shadow: 0 0 12px #ffffff;
      }
      100% {
        transform: scale(1);
      }
    }

    .fab-badge.animate-pop {
      animation: badgePop 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    @keyframes cardEntry {
      0% {
        opacity: 0;
        transform: translateY(-20px) scale(0.92);
        border-color: #f97316;
        box-shadow: 0 0 25px rgba(249, 115, 22, 0.6);
      }
      50% {
        border-color: #f43f5e;
        box-shadow: 0 0 35px rgba(244, 63, 94, 0.8);
      }
      100% {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }

    .card.new-card-animate {
      animation: cardEntry 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
  `;

  // HTML layout template
  const uiTemplate = `
    <div class="fab" id="fab">
      <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
      <div class="fab-badge" id="fab-badge" style="display: none;">0</div>
    </div>

    <div class="sidebar" id="sidebar">
      <div class="header">
        <div class="header-top">
          <div class="title-group">
            <div class="logo-icon">
              <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            </div>
            <div class="title-wrapper">
              <div class="title">SlotSync LeadFlow</div>
              <div class="subtitle">by Satyam Soni</div>
            </div>
          </div>
          <button class="close-btn" id="close-btn" title="Collapse Panel">
            <svg viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
        </div>
        
        <div class="control-group">
          <div class="control-item">
            <div class="control-label">
              <span>Active Monitoring</span>
              <span class="control-sub">Scan posts as you scroll</span>
            </div>
            <label class="switch">
              <input type="checkbox" id="monitoring-toggle">
              <span class="slider"></span>
            </label>
          </div>
          <div class="control-item">
            <div class="control-label">
              <span>Expand Post Text</span>
              <span class="control-sub">Opens only post "...more" text</span>
            </div>
            <label class="switch">
              <input type="checkbox" id="auto-expand-toggle">
              <span class="slider"></span>
            </label>
          </div>
        </div>
        
        <div class="stats-row">
          <div class="stat-card">
            <div class="stat-val scans" id="scans-counter">0</div>
            <div class="stat-lbl">Scanned</div>
          </div>
          <div class="stat-card">
            <div class="stat-val emails" id="emails-counter">0</div>
            <div class="stat-lbl">Emails</div>
          </div>
        </div>
        
        <div class="debug-console" id="debug-console">
          <div class="debug-console-title">
            <span>Diagnostics Console</span>
            <span id="debug-status" style="color: #10b981;">● ACTIVE</span>
          </div>
          <div id="debug-console-content">Analyzing page structure...</div>
        </div>
      </div>
      
      <div class="content-list" id="content-list">
        <!-- Card items go here -->
      </div>
      
      <div class="footer">
        <div class="footer-actions">
          <button class="action-btn primary" id="export-btn" title="Export CSV">
            <svg viewBox="0 0 24 24"><path d="M19 12v7H5v-7H3v7c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-7h-2zm-6 .67l2.59-2.58L17 11.5l-5 5-5-5 1.41-1.41L11 12.67V3h2v9.67z"/></svg>
            Export CSV
          </button>
          <button class="action-btn secondary" id="copy-all-btn" title="Copy All Emails">
            <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1 0 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            Copy All
          </button>
        </div>
        <button class="action-btn danger" id="clear-btn" title="Clear Extracted Emails">
          <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
          Clear Extracted Emails
        </button>
        <div class="developer-signature">
          <span>Developed by <strong>Satyam Soni</strong></span>
          <a href="https://sslotsync.online" target="_blank">SslotSync.online</a>
        </div>
      </div>
      
      <div class="toast" id="toast">Copied to clipboard!</div>
    </div>
  `;

  // Append elements inside shadow
  shadow.appendChild(styleEl);

  const pageStyleEl = document.createElement('style');
  pageStyleEl.id = 'nova-email-extractor-page-markers';
  pageStyleEl.textContent = `
    [data-nova-scan-state] {
      position: relative !important;
      transition: box-shadow 0.25s ease, outline-color 0.25s ease;
    }

    [data-nova-scan-state="scanning"] {
      box-shadow: inset 7px 0 0 #f97316, 0 0 0 2px rgba(249, 115, 22, 0.55), 0 0 18px rgba(249, 115, 22, 0.25) !important;
      outline: 2px solid rgba(249, 115, 22, 0.45) !important;
      outline-offset: 2px !important;
    }

    [data-nova-scan-state="scanned"] {
      box-shadow: inset 7px 0 0 #ea580c, 0 0 0 2px rgba(234, 88, 12, 0.42) !important;
      outline: 2px solid rgba(234, 88, 12, 0.32) !important;
      outline-offset: 2px !important;
    }
  `;
  document.head.appendChild(pageStyleEl);

  const wrapper = document.createElement('div');
  wrapper.innerHTML = uiTemplate;
  shadow.appendChild(wrapper);

  // References
  const fab = shadow.getElementById('fab');
  const fabBadge = shadow.getElementById('fab-badge');
  const sidebar = shadow.getElementById('sidebar');
  const closeBtn = shadow.getElementById('close-btn');
  const monitoringToggle = shadow.getElementById('monitoring-toggle');
  const autoExpandToggle = shadow.getElementById('auto-expand-toggle');
  const scansCounter = shadow.getElementById('scans-counter');
  const emailsCounter = shadow.getElementById('emails-counter');
  const contentList = shadow.getElementById('content-list');
  const exportBtn = shadow.getElementById('export-btn');
  const copyAllBtn = shadow.getElementById('copy-all-btn');
  const clearBtn = shadow.getElementById('clear-btn');
  const toast = shadow.getElementById('toast');

  // --- LOCAL STORAGE HANDLING ---
  function loadInitialState() {
    // Reset UI state synchronously so it closes immediately on load
    if (sidebar) sidebar.classList.remove('open');
    if (fab) fab.style.display = 'flex';
    if (monitoringToggle) monitoringToggle.checked = false;
    
    active = false;
    emails = [];
    sessionScannedCount = 0;
    processedPosts.clear();
    
    // Clear UI synchronously to avoid race condition/stale data
    updateStatsDisplay();
    renderEmailList();
    updateFabBadge();

    chrome.storage.local.get({ autoExpand: true }, (result) => {
      autoExpand = result.autoExpand !== false;
      if (autoExpandToggle) autoExpandToggle.checked = autoExpand;

      // Force clear emails and active state on reload, but keep the user's expand setting.
      chrome.storage.local.set({ 
        emails: [], 
        active: false, 
        autoExpand
      }, () => {
        updateStatsDisplay();
        renderEmailList();
        updateFabBadge();
      });
    });
  }

  function handlePageNavigation() {
    console.log("SlotSync LeadFlow: Page navigation detected, resetting extension state.");
    
    // Close sidebar and show FAB
    if (sidebar) sidebar.classList.remove('open');
    if (fab) fab.style.display = 'flex';
    
    // Turn off active monitoring
    active = false;
    if (monitoringToggle) monitoringToggle.checked = false;
    stopObserver();
    stopGlobalScanInterval();
    
    // Clear data from memory
    emails = [];
    sessionScannedCount = 0;
    processedPosts.clear();
    clearPostMarkers();
    
    // Clear UI synchronously to avoid race condition/stale data
    updateStatsDisplay();
    renderEmailList();
    updateFabBadge();
    
    chrome.storage.local.get({ autoExpand: true }, (result) => {
      autoExpand = result.autoExpand !== false;
      if (autoExpandToggle) autoExpandToggle.checked = autoExpand;

      chrome.storage.local.set({ 
        emails: [], 
        active: false, 
        autoExpand
      }, () => {
        updateStatsDisplay();
        renderEmailList();
        updateFabBadge();
      });
    });
  }

  function syncNewEmails() {
    if (!AUTO_SEND) return;
    emails.forEach((item) => {
      if (syncedEmails.has(item.email)) return;
      syncedEmails.add(item.email);
      chrome.runtime.sendMessage(
        {
          action: 'AUTO_ENQUEUE',
          serverUrl: COLDMAILER_URL,
          apiKey: COLDMAILER_KEY,
          emails: [item.email],
          postUrl: item.postUrl,
        },
        (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            syncedEmails.delete(item.email); // retry on the next scan
            console.warn('ColdMailer enqueue failed:', chrome.runtime.lastError || (res && res.error));
          } else if (res.data && res.data.accepted > 0) {
            showToast('Queued for auto-mail');
          }
        }
      );
    });
  }

  function saveEmails() {
    chrome.storage.local.set({ emails });
    updateFabBadge();
    syncNewEmails();
  }

  // --- UI ACTIONS ---
  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 2000);
  }

  function updateStatsDisplay() {
    scansCounter.textContent = sessionScannedCount;
    emailsCounter.textContent = emails.length;
  }

  function updateFabBadge() {
    if (emails.length > 0) {
      fabBadge.textContent = emails.length;
      fabBadge.style.display = 'flex';
    } else {
      fabBadge.style.display = 'none';
    }
  }

  function triggerNewEmailAnimation() {
    justAddedNewEmail = true;
    
    // Animate FAB and badge
    if (fab) {
      fab.classList.remove('animate-pulse-bounce');
      void fab.offsetWidth; // Trigger reflow to restart animation
      fab.classList.add('animate-pulse-bounce');
      setTimeout(() => fab.classList.remove('animate-pulse-bounce'), 850);
    }
    
    if (fabBadge) {
      fabBadge.classList.remove('animate-pop');
      void fabBadge.offsetWidth; // Trigger reflow to restart animation
      fabBadge.classList.add('animate-pop');
      setTimeout(() => fabBadge.classList.remove('animate-pop'), 650);
    }
  }

  function renderEmailList() {
    if (emails.length === 0) {
      contentList.innerHTML = `
        <div class="empty-state">
          <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 6l-10 7L2 6" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <div class="empty-title">No emails collected yet</div>
          <div class="empty-desc">Enable "Active Monitoring" and scroll through visible public posts to extract emails.</div>
        </div>
      `;
      return;
    }

    contentList.innerHTML = emails.map((item, idx) => {
      const authorName = escapeHtml(item.authorName);
      const email = escapeHtml(item.email);
      const snippet = escapeHtml(item.snippet);
      const dateStr = new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      const isNew = justAddedNewEmail && idx === 0;
      const animationClass = isNew ? ' new-card-animate' : '';

      return `
        <div class="card${animationClass}" data-urn="${item.urn}">
          <div class="card-top">
            <div class="email-display" title="Double click to select">${email}</div>
            <button class="copy-btn" data-email="${email}" title="Copy Email">
              <svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
            </button>
          </div>
          <div class="card-meta">
            <div>
              ${item.authorProfile && item.authorProfile !== '#' ? `
                <a href="${item.authorProfile}" target="_blank" class="meta-author">
                  ${authorName}
                  <svg viewBox="0 0 24 24"><path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>
                </a>
              ` : `<span class="meta-author" style="cursor: default;">${authorName}</span>`}
            </div>
            ${snippet ? `<div class="meta-snippet" title="${snippet}">${snippet}</div>` : ''}
          </div>
          <div class="card-bottom">
            <a href="${item.postUrl}" target="_blank" class="post-link">
              View Original Post
              <svg viewBox="0 0 24 24"><path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>
            </a>
            <div class="post-time">${dateStr}</div>
          </div>
        </div>
      `;
    }).join('');

    // Attach copy button listeners inside contentList
    contentList.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const emailStr = btn.getAttribute('data-email');
        copyToClipboard(emailStr);

        // Visual click feedback
        const origSvg = btn.innerHTML;
        btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>`;
        btn.style.background = '#10b981';
        setTimeout(() => {
          btn.innerHTML = origSvg;
          btn.style.background = '';
        }, 1200);
      });
    });

    justAddedNewEmail = false;
  }

  function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
      showToast('Copied to clipboard!');
    }).catch(err => {
      // Fallback
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        showToast('Copied to clipboard!');
      } catch (e) {
        console.error('Fallback copy failed', e);
      }
      document.body.removeChild(textarea);
    });
  }

  // --- BUTTON EVENT LISTENERS ---
  monitoringToggle.addEventListener('change', (e) => {
    active = e.target.checked;
    chrome.storage.local.set({ active });
    if (active) {
      startObserver();
      globalEmailScan();
      startGlobalScanInterval();
      showToast('Active Monitoring: ON');
    } else {
      stopObserver();
      stopGlobalScanInterval();
      showToast('Active Monitoring: OFF');
    }
    updateStatsDisplay();
  });

  autoExpandToggle.addEventListener('change', (e) => {
    autoExpand = e.target.checked;
    chrome.storage.local.set({ autoExpand });
    if (autoExpand && active) {
      scanViewport();
    }
    showToast(autoExpand ? 'Post Expand: ON' : 'Post Expand: OFF');
  });

  closeBtn.addEventListener('click', () => {
    sidebar.classList.remove('open');
    fab.style.display = 'flex';
  });

  fab.addEventListener('click', () => {
    sidebar.classList.add('open');
    fab.style.display = 'none';
  });

  copyAllBtn.addEventListener('click', () => {
    if (emails.length === 0) {
      showToast('No emails to copy');
      return;
    }
    const allEmails = emails.map(item => item.email).join(', ');
    copyToClipboard(allEmails);
  });

  exportBtn.addEventListener('click', () => {
    if (emails.length === 0) {
      showToast('No emails to export');
      return;
    }
    const headers = ['Email', 'Author Name', 'Author Profile', 'Post Link', 'Snippet', 'Timestamp'];
    const rows = emails.map(item => [
      item.email,
      item.authorName,
      item.authorProfile,
      item.postUrl,
      item.snippet,
      item.timestamp
    ]);
    
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(val => `"${(val || '').replace(/"/g, '""')}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `linkedin_emails_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('CSV Exported!');
  });

  clearBtn.addEventListener('click', () => {
    if (emails.length === 0) return;
    if (confirm('Are you sure you want to clear all collected emails?')) {
      emails = [];
      saveEmails();
      renderEmailList();
      updateStatsDisplay();
      showToast('Cleared list');
    }
  });

  // --- SCRAPING LOGIC ---
  function extractEmails(text) {
    if (!text) return [];
    // Strict regex to match correct emails and skip image/asset urls
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const matches = text.match(emailRegex) || [];
    
    // Filtering out false positives (e.g., standard file extensions if parsed)
    const validEmails = matches.filter(email => {
      const lower = email.toLowerCase();
      return !lower.endsWith('.png') && !lower.endsWith('.jpg') && !lower.endsWith('.jpeg') && !lower.endsWith('.gif') && !lower.endsWith('.webp');
    });

    return [...new Set(validEmails.map(e => e.toLowerCase()))];
  }

  function getAuthorDetails(postEl) {
    let name = '';
    let profileUrl = '';
    
    // Find all links to profile
    const profileLinks = postEl.querySelectorAll('a[href*="/in/"]');
    for (const link of profileLinks) {
      if (link.href) {
        // Clean URL to base profile link
        profileUrl = link.href.split('?')[0];
        
        // Check if this link contains the text
        const txt = link.innerText.trim();
        if (txt && !name) {
          // Remove connection levels like "• 3rd+" or similar
          name = txt.split('\n')[0].replace(/•.*/, '').trim();
        }
      }
    }
    
    // Fallback to name selectors if none had text
    if (!name) {
      const nameSelectors = [
        '.update-components-actor__title span[dir="ltr"]',
        '.update-components-actor__title',
        '.feed-shared-actor__title span[dir="ltr"]',
        '.feed-shared-actor__title',
        '.update-components-actor__name',
        '.feed-shared-actor__name',
        '.entity-result__title-text a'
      ];
      
      for (const sel of nameSelectors) {
        const el = postEl.querySelector(sel);
        if (el) {
          name = el.innerText.trim();
          if (name) break;
        }
      }
      if (name) {
        name = name.split('\n')[0].replace(/•.*/, '').trim();
      }
    }
    
    // Fallback to link selectors
    if (!profileUrl) {
      const linkSelectors = [
        'a.update-components-actor__image',
        'a.feed-shared-actor__image'
      ];
      for (const sel of linkSelectors) {
        const el = postEl.querySelector(sel);
        if (el && el.href) {
          profileUrl = el.href.split('?')[0];
          break;
        }
      }
    }
    
    return {
      name: name || 'LinkedIn User',
      profileUrl: profileUrl || '#'
    };
  }

  function getPostDetails(postEl) {
    let urn = postEl.getAttribute('data-urn');
    if (!urn) {
      const childWithUrn = postEl.querySelector('[data-urn]');
      if (childWithUrn) {
        urn = childWithUrn.getAttribute('data-urn');
      }
    }
    
    let postUrl = '';
    if (urn) {
      postUrl = `https://www.linkedin.com/feed/update/${urn}`;
    } else {
      const linkEl = postEl.querySelector('a[href*="/feed/update/urn:li:activity:"], a[href*="/update/urn:li:activity:"]');
      if (linkEl) {
        postUrl = linkEl.href;
        const match = postUrl.match(/urn:li:activity:\d+/);
        if (match) urn = match[0];
      }
    }
    
    if (!postUrl) {
      postUrl = window.location.href;
    }

    if (!urn) {
      if (!postEl.dataset.novaPostId) {
        tempPostIdCounter += 1;
        postEl.dataset.novaPostId = `visible-post-${Date.now()}-${tempPostIdCounter}`;
      }
      urn = postEl.dataset.novaPostId;
    }
    
    return { 
      urn,
      postUrl 
    };
  }

  function getPostText(postEl) {
    const textSelectors = [
      '.feed-shared-update-v2__description',
      '.feed-shared-inline-show-more-text',
      '.update-components-text',
      '.feed-shared-text',
      '.entity-result__summary'
    ];
    
    let text = '';
    for (const sel of textSelectors) {
      const el = postEl.querySelector(sel);
      if (el) {
        text = el.innerText;
        if (text) break;
      }
    }
    
    if (!text) {
      text = postEl.innerText || '';
    }
    
    return text.trim();
  }

  // =============================================
  // === SCANNING ENGINE (no virtual cursor) ===
  // =============================================

  // --- UTILITIES ---
  function isElementVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isElementInViewport(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const wH = window.innerHeight || document.documentElement.clientHeight;
    const wW = window.innerWidth || document.documentElement.clientWidth;
    return rect.bottom > -800 && rect.top < (wH + 1200) && rect.right > 0 && rect.left < wW;
  }

  // --- SEE-MORE BUTTON DETECTION ---
  function isSeeMoreButton(btn) {
    if (!btn) return false;

    // Guard: skip SVG elements and elements without text
    const rawText = btn.innerText || btn.textContent || '';
    const classes = (typeof btn.className === 'string') ? btn.className : '';

    if (!rawText && !classes) return false;

    // Guard: reject hashtags (like #cplusplus, which ends with 'plus' and would trigger the see-more check)
    // and reject any actual navigating links (A tags with hrefs)
    const checkText = rawText.replace(/[\s\u00a0]+/g, ' ').trim().toLowerCase();
    if (checkText.startsWith('#')) return false;

    if (btn.tagName === 'A') {
      const href = btn.getAttribute('href');
      if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
        return false;
      }
    }

    // 1. Class name checks
    if (classes) {
      const lc = classes.toLowerCase();
      if (lc.includes('see-more') || lc.includes('show-more') ||
          lc.includes('see_more') || lc.includes('show_more') ||
          lc.includes('inline-show-more') || lc.includes('line-clamp__more')) {
        return true;
      }
      // LinkedIn toggle classes that relate to text expansion
      if (lc.includes('toggle') && (lc.includes('more') || lc.includes('text') || lc.includes('show'))) {
        return true;
      }
    }

    // 2. aria-label check
    const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (ariaLabel.includes('see more') || ariaLabel.includes('show more')) {
      return true;
    }

    // 3. Text content checks
    const txt = rawText.replace(/[\s\u00a0]+/g, ' ').trim().toLowerCase();
    if (!txt || txt.length > 25) return false;

    // Exact matches
    const exactMatches = [
      'more', 'see more', '...more', '... more', '…more', '… more',
      '…see more', '… see more', 'voir plus', '…voir plus', '… voir plus',
      '... voir plus', 'más', '…más', '... más', 'mehr', '…mehr', '... mehr'
    ];
    if (exactMatches.includes(txt)) return true;

    // Ends-with checks (but exclude "learn more", "read more", etc.)
    const excludeWords = ['learn', 'buy', 'shop', 'sign', 'read', 'load', 'apply', 'know'];
    if ((txt.endsWith('more') || txt.endsWith('plus') || txt.endsWith('más') || txt.endsWith('mehr')) &&
        !excludeWords.some(w => txt.includes(w)) && txt.length < 20) {
      return true;
    }

    // Ellipsis + "more" combos
    if ((txt.includes('…') || txt.includes('...')) &&
        (txt.includes('more') || txt.includes('plus') || txt.includes('más') || txt.includes('mehr') || txt.includes('voir')) &&
        txt.length < 20) {
      return true;
    }

    return false;
  }

  // --- POST CONTAINER DETECTION ---
  function isPostContainer(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    
    // 1. Must contain a profile link
    const hasProfile = el.querySelector('a[href*="/in/"]');
    if (!hasProfile) return false;

    // 2. Must contain post text / description
    const hasText = el.innerText && el.innerText.length > 30;
    if (!hasText) return false;

    // 3. Must contain interaction indicators (Comment, Repost, Like, Send, etc.)
    const inner = el.innerHTML.toLowerCase();
    const hasInteract = inner.includes('comment') || inner.includes('repost') || inner.includes('like') || inner.includes('send') ||
                        inner.includes('aime') || inner.includes('partag') || inner.includes('republi') || inner.includes('envoy') ||
                        inner.includes('recomendar') || inner.includes('compartir') || inner.includes('gusta') ||
                        inner.includes('teilen') || inner.includes('gefällt') || inner.includes('kommentar');
    if (!hasInteract) return false;

    return true;
  }

  function findParentPostContainer(el) {
    if (!el) return null;
    let current = el;
    for (let i = 0; i < 12 && current && current !== document.body; i++) {
      if (current.matches && current.matches(postSelector)) return current;
      if (isPostContainer(current)) return current;
      current = current.parentElement;
    }
    return null;
  }

  function findAllVisiblePosts() {
    const found = new Set();

    // Strategy 1: Match standard selectors
    try {
      document.querySelectorAll(postSelector).forEach(el => {
        if (isElementInViewport(el) && el.innerText && el.innerText.length > 30) {
          found.add(el);
        }
      });
    } catch (e) {}

    // Strategy 2: Match elements using our robust post card detector walked up from profile links
    try {
      const profileLinks = document.querySelectorAll('a[href*="/in/"]');
      profileLinks.forEach(link => {
        const parentPost = findParentPostContainer(link);
        if (parentPost && isElementInViewport(parentPost)) {
          found.add(parentPost);
        }
      });
    } catch (e) {}

    // Strategy 3: Walk up from text content areas
    try {
      const textAreas = document.querySelectorAll(
        '.feed-shared-inline-show-more-text, .update-components-text, ' +
        '.feed-shared-text, .entity-result__summary, .feed-shared-update-v2__description, ' +
        '[class*="update-components-text"], [class*="feed-shared-text"]'
      );
      textAreas.forEach(textEl => {
        if (!isElementInViewport(textEl)) return;
        const container = findParentPostContainer(textEl);
        if (container) found.add(container);
      });
    } catch (e) {}

    return Array.from(found);
  }

  // --- FIND ALL SEE-MORE BUTTONS IN VIEWPORT ---
  function findAllVisibleSeeMoreButtons() {
    const buttons = [];
    try {
      const posts = findAllVisiblePosts();
      posts.forEach(post => {
        const candidates = post.querySelectorAll(
          'button, [role="button"], a, span[class*="more"], span[class*="toggle"], ' +
          'span[class*="clamp"], div[role="button"]'
        );
        candidates.forEach(el => {
          // Skip already clicked
          if (el.hasAttribute('data-nova-clicked')) return;

          try {
            if (isSeeMoreButton(el) && isElementVisible(el) && isElementInViewport(el)) {
              const clickTarget = el.closest('button, [role="button"], a') || el;
              if (!clickTarget.hasAttribute('data-nova-clicked')) {
                buttons.push(clickTarget);
              }
            }
          } catch (e) {}
        });
      });
    } catch (e) {}
    return buttons;
  }

  // --- CLICK A SEE-MORE BUTTON (direct, no synthetic events) ---
  function clickSeeMoreButton(btn) {
    if (!btn || btn.hasAttribute('data-nova-clicked')) return;
    btn.setAttribute('data-nova-clicked', 'true');

    console.log('SlotSync LeadFlow: Clicking see-more button:', btn.innerText || btn.textContent);

    try {
      btn.click();
    } catch (e) {
      console.error('SlotSync LeadFlow: click() failed:', e);
    }

    // Self-healing: if button is still visible after 3s, it means the click failed — allow retry
    const ref = btn;
    setTimeout(() => {
      try {
        if (ref && ref.isConnected && isElementVisible(ref) && isSeeMoreButton(ref)) {
          console.log('SlotSync LeadFlow: Self-healing — see-more still visible, clearing for retry');
          ref.removeAttribute('data-nova-clicked');
        }
      } catch (e) {}
    }, 3000);
  }

  // --- CLEAR VISUAL MARKERS ---
  function clearPostMarkers() {
    try {
      document.querySelectorAll('[data-nova-scan-state]').forEach(el => {
        el.removeAttribute('data-nova-scan-state');
      });
      document.querySelectorAll('[data-nova-clicked]').forEach(el => {
        el.removeAttribute('data-nova-clicked');
      });
    } catch (e) {}
  }

  // --- PROCESS A SINGLE POST FOR EMAILS ---
  function processPostForEmails(postEl) {
    if (!active || !postEl) return;

    const { urn, postUrl } = getPostDetails(postEl);
    const text = getPostText(postEl);
    const textLength = text.length;

    // Skip if already processed and the text hasn't grown (e.g., was expanded)
    if (processedPosts.has(urn) && textLength <= processedPosts.get(urn)) return;

    const isNewPost = !processedPosts.has(urn);
    processedPosts.set(urn, textLength);

    if (isNewPost) {
      sessionScannedCount++;
      updateStatsDisplay();
    }

    // Orange border: scanning
    postEl.setAttribute('data-nova-scan-state', 'scanning');

    // After 0.6s, transition to "scanned" state (dimmer orange)
    setTimeout(() => {
      if (postEl.isConnected) {
        postEl.setAttribute('data-nova-scan-state', 'scanned');
      }
      // After another 1.5s, remove the border entirely
      setTimeout(() => {
        if (postEl.isConnected) {
          postEl.removeAttribute('data-nova-scan-state');
        }
      }, 1500);
    }, 600);

    // Extract emails from current text
    extractAndStoreEmails(postEl, urn, postUrl);

    // If auto-expand is on, also re-extract after a delay (post may have expanded)
    if (autoExpand) {
      setTimeout(() => {
        extractAndStoreEmails(postEl, urn, postUrl);
      }, 800);
    }
  }

  function extractAndStoreEmails(postEl, urn, postUrl) {
    if (!postEl.isConnected) return;
    const currentDetails = getPostDetails(postEl);
    if (currentDetails.urn !== urn) return; // The element was recycled!

    const text = getPostText(postEl);
    const foundEmails = extractEmails(text);

    if (foundEmails.length === 0) return;

    const author = getAuthorDetails(postEl);
    const textSnippet = text.substring(0, 150).replace(/\n/g, ' ') + (text.length > 150 ? '…' : '');

    let updated = false;
    foundEmails.forEach(email => {
      if (!emails.some(item => item.email === email)) {
        emails.unshift({
          email,
          authorName: author.name,
          authorProfile: author.profileUrl,
          postUrl,
          snippet: textSnippet,
          urn,
          timestamp: new Date().toISOString()
        });
        updated = true;
      }
    });

    if (updated) {
      saveEmails();
      triggerNewEmailAnimation();
      renderEmailList();
      updateStatsDisplay();
    }
  }

  // --- GLOBAL EMAIL SCAN (body-wide fallback) ---
  function globalEmailScan() {
    if (!active) return;

    const text = document.body.innerText || '';
    const foundEmails = extractEmails(text);
    if (foundEmails.length === 0) return;

    let updated = false;
    foundEmails.forEach(email => {
      if (!emails.some(item => item.email === email)) {
        // Try to find the element containing this email
        let author = { name: 'LinkedIn Post', profileUrl: '#' };
        let postUrl = window.location.href;
        let urn = `global-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
        let textSnippet = 'Found in visible post text';

        try {
          const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
          let node;
          while (node = walker.nextNode()) {
            if (node.nodeValue && node.nodeValue.toLowerCase().includes(email)) {
              const parentPost = findParentPostContainer(node.parentElement);
              if (parentPost) {
                author = getAuthorDetails(parentPost);
                const details = getPostDetails(parentPost);
                postUrl = details.postUrl;
                urn = details.urn;
                const fullText = getPostText(parentPost);
                textSnippet = fullText.substring(0, 150).replace(/\n/g, ' ') + (fullText.length > 150 ? '…' : '');

                if (!processedPosts.has(urn)) {
                  processedPosts.set(urn, textSnippet.length);
                  sessionScannedCount++;
                }
              }
              break;
            }
          }
        } catch (e) {}

        emails.unshift({
          email,
          authorName: author.name,
          authorProfile: author.profileUrl,
          postUrl,
          snippet: textSnippet,
          urn,
          timestamp: new Date().toISOString()
        });
        updated = true;
      }
    });

    if (updated) {
      saveEmails();
      triggerNewEmailAnimation();
      renderEmailList();
      updateStatsDisplay();
    }
  }

  // =============================================
  // === MAIN SCAN FUNCTION (called on scroll) ===
  // =============================================
  function scanViewport() {
    if (!active) return;

    // 1. Find and click see-more buttons in viewport
    if (autoExpand) {
      const seeMoreBtns = findAllVisibleSeeMoreButtons();
      seeMoreBtns.forEach(btn => clickSeeMoreButton(btn));
    }

    // 2. Find visible posts and process them
    const posts = findAllVisiblePosts();
    posts.forEach(post => processPostForEmails(post));

    // 3. Global email fallback scan
    globalEmailScan();
  }

  // --- SCROLL LISTENER (throttled) ---
  let scrollTimer = null;
  function onScrollThrottled() {
    if (!active) return;
    if (scrollTimer) return;
    scrollTimer = setTimeout(() => {
      scrollTimer = null;
      scanViewport();
    }, 100);
  }

  // --- MUTATION OBSERVER (watch for new posts added to DOM) ---
  let mutationObserver = null;

  function startMutationObserver() {
    if (mutationObserver) return;
    mutationObserver = new MutationObserver((mutations) => {
      let shouldScan = false;
      for (const mutation of mutations) {
        if (mutation.addedNodes && mutation.addedNodes.length > 0) {
          shouldScan = true;
          break;
        }
      }
      if (shouldScan && active) {
        // Small debounce so we don't scan on every tiny DOM change
        setTimeout(() => scanViewport(), 100);
      }
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });
  }

  // --- PERIODIC SCAN INTERVAL ---
  function startGlobalScanInterval() {
    if (globalScanInterval) return;
    globalScanInterval = setInterval(() => {
      if (active) scanViewport();
    }, 800);
  }

  function stopGlobalScanInterval() {
    if (globalScanInterval) {
      clearInterval(globalScanInterval);
      globalScanInterval = null;
    }
  }

  // --- OBSERVER CONTROL (for monitoring toggle) ---
  function startObserver() {
    window.addEventListener('scroll', onScrollThrottled, { passive: true });
    startMutationObserver();
    startGlobalScanInterval();
    // Do an immediate scan
    scanViewport();
  }

  function stopObserver() {
    window.removeEventListener('scroll', onScrollThrottled);
    stopGlobalScanInterval();
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }
    clearPostMarkers();
  }

  // --- DIAGNOSTICS CONSOLE ---
  function updateDebugConsole() {
    const consoleEl = shadow.getElementById('debug-console-content');
    if (!consoleEl) return;

    try {
      let html = '';
      const url = window.location.href.split('?')[0];
      html += `<div><strong>URL:</strong> ${escapeHtml(url)}</div>`;

      const posts = findAllVisiblePosts();
      html += `<div><strong>Visible Posts:</strong> ${posts.length}</div>`;

      const seeMoreBtns = findAllVisibleSeeMoreButtons();
      html += `<div><strong>See-more buttons:</strong> ${seeMoreBtns.length}</div>`;

      seeMoreBtns.forEach((btn, i) => {
        if (i < 3) {
          const tag = btn.tagName.toLowerCase();
          const cls = (typeof btn.className === 'string') ? btn.className.split(' ').slice(0, 2).join('.') : '';
          const txt = (btn.innerText || '').trim().substring(0, 30);
          html += `<div> - &lt;${tag}.${cls}&gt; "${escapeHtml(txt)}"</div>`;
        }
      });

      // --- DETAILED DIAGNOSTICS ---
      const totalRawPosts = document.querySelectorAll(postSelector).length;
      html += `<div style="margin-top: 6px; border-top: 1px dashed rgba(255,255,255,0.1); padding-top: 4px;">`;
      html += `<strong>Raw Post Elements:</strong> ${totalRawPosts}</div>`;
      
      const selectors = postSelector.split(', ');
      let selectorCounts = '';
      selectors.forEach(sel => {
        const count = document.querySelectorAll(sel).length;
        if (count > 0) {
          selectorCounts += `${sel}(${count}) `;
        }
      });
      html += `<div><strong>Matches:</strong> ${selectorCounts || 'None'}</div>`;

      // Check viewport statistics for the first raw match
      const firstRaw = document.querySelector(postSelector);
      if (firstRaw) {
        const rect = firstRaw.getBoundingClientRect();
        const inV = isElementInViewport(firstRaw);
        html += `<div><strong>First Post Viewport:</strong> inV=${inV} t=${Math.round(rect.top)} b=${Math.round(rect.bottom)} h=${Math.round(rect.height)} w=${Math.round(rect.width)}</div>`;
      }

      // --- PARENT TRACE FROM PROFILE LINKS ---
      const profileLinks = Array.from(document.querySelectorAll('a[href*="/in/"]'));
      html += `<div style="margin-top: 4px; border-top: 1px dotted rgba(255,255,255,0.1); padding-top: 2px;">`;
      html += `<strong>Profiles Found:</strong> ${profileLinks.length}</div>`;
      if (profileLinks.length > 0) {
        profileLinks.slice(0, 1).forEach((link, idx) => {
          let curr = link.parentElement;
          let depth = 0;
          while (curr && curr !== document.body && depth < 10) {
            const tag = curr.tagName.toLowerCase();
            const cls = (typeof curr.className === 'string' && curr.className) ? `.${curr.className.split(' ').slice(0,2).join('.')}` : '';
            const hasUrn = curr.hasAttribute('data-urn') || curr.hasAttribute('data-activity-urn') ? '[URN]' : '';
            
            // Diagnostics for container eligibility
            const matchesPostSelector = curr.matches && curr.matches(postSelector);
            const hasProfile = !!curr.querySelector('a[href*="/in/"]');
            const txtLen = curr.innerText ? curr.innerText.length : 0;
            const inner = curr.innerHTML ? curr.innerHTML.toLowerCase() : '';
            const hasInteract = inner.includes('comment') || inner.includes('repost') || inner.includes('like') || inner.includes('send') ||
                                inner.includes('aime') || inner.includes('partag') || inner.includes('republi') || inner.includes('envoy') ||
                                inner.includes('recomendar') || inner.includes('compartir') || inner.includes('gusta') ||
                                inner.includes('teilen') || inner.includes('gefällt') || inner.includes('kommentar');
            
            html += `<div style="font-size:9px; padding-left: 4px; font-family:monospace;">${depth}: &lt;${tag}${cls}&gt; ${hasUrn} (sel:${matchesPostSelector}, prof:${hasProfile}, txt:${txtLen}, int:${hasInteract})</div>`;
            curr = curr.parentElement;
            depth++;
          }
        });
      }

      html += `<div style="margin-top: 4px;"><strong>Processed:</strong> ${processedPosts.size} | <strong>Emails:</strong> ${emails.length}</div>`;
      html += `<div><strong>Active:</strong> ${active} | <strong>AutoExpand:</strong> ${autoExpand}</div>`;

      consoleEl.innerHTML = html;
    } catch (err) {
      consoleEl.innerHTML = `<span style="color: #ef4444;">Error: ${escapeHtml(err.message)}</span>`;
    }
  }

  // =============================================
  // === INITIALIZE ===
  // =============================================
  loadInitialState();
  startMutationObserver();

  // Diagnostics loop
  setInterval(() => updateDebugConsole(), 2000);

  // SPA navigation detection (fast polling)
  let lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      handlePageNavigation();
    }
  }, 250);

  // Instant SPA navigation via browser events
  window.addEventListener('popstate', () => {
    setTimeout(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        handlePageNavigation();
      }
    }, 50);
  });

  window.addEventListener('hashchange', () => {
    setTimeout(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        handlePageNavigation();
      }
    }, 50);
  });

})();
